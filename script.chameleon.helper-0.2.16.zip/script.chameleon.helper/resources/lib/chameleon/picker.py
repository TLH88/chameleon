# -*- coding: utf-8 -*-
"""What to Watch: pick a few criteria, get a shuffled list of matches.

Streaming matches come from TMDb through TMDb Helper's discover lists (so they
play through whatever TMDb Helper player you use, e.g. Fen Light). Library
matches come straight from the Kodi video library (your NAS).
"""
import datetime
import json
import os
import random
import time
from urllib.parse import parse_qsl, quote, quote_plus, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from . import common

CRITERIA_FILE = "picker.json"
RESULTS_FILE = "picker_results.json"
TMDBH = "plugin.video.themoviedb.helper"
SELF_URL = "plugin://script.chameleon.helper/"
POOL_SIZE = 60
SHOW = 20
# TMDb genre ids (stable, published by TMDb). Names are shown to the user, ids go into the query.
GENRE_IDS = {
    "movie": {"Action": 28, "Adventure": 12, "Animation": 16, "Comedy": 35, "Crime": 80, "Documentary": 99, "Drama": 18, "Family": 10751,
              "Fantasy": 14, "History": 36, "Horror": 27, "Music": 10402, "Mystery": 9648, "Romance": 10749, "Science Fiction": 878,
              "Thriller": 53, "War": 10752, "Western": 37},
    "tv": {"Action & Adventure": 10759, "Animation": 16, "Comedy": 35, "Crime": 80, "Documentary": 99, "Drama": 18, "Family": 10751,
           "Kids": 10762, "Mystery": 9648, "Reality": 10764, "Sci-Fi & Fantasy": 10765, "War & Politics": 10768, "Western": 37},
}
GENRES = {kind: sorted(table) for kind, table in GENRE_IDS.items()}
# stars (1-5) -> minimum average score out of 10
STAR_FLOOR = {1: 2.0, 2: 4.0, 3: 6.0, 4: 7.0, 5: 8.0}
SOURCES = (("stream", "Streaming (TMDb, plays through your TMDb Helper player)"), ("library", "My library (NAS)"), ("both", "Both"))
DEFAULT = {"media": "movie", "source": "both", "genres": [], "year_from": 0, "year_to": 0, "actor": "", "stars": 0}


# -- criteria --------------------------------------------------------------
def load():
    return dict(DEFAULT, **common.read_json(common.data_file(CRITERIA_FILE)))


def save(criteria):
    common.write_json(common.data_file(CRITERIA_FILE), criteria)


def _years_label(c):
    if not c["year_from"] and not c["year_to"]:
        return "Any"
    if c["year_from"] == c["year_to"]:
        return str(c["year_from"])
    if c["year_from"] % 10 == 0 and c["year_to"] == c["year_from"] + 9:
        return "%ds" % c["year_from"]
    return "%s to %s" % (c["year_from"] or "earliest", c["year_to"] or "now")


def describe(c):
    parts = ["Movies" if c["media"] == "movie" else "TV shows"]
    if c["genres"]:
        parts.append(" or ".join(c["genres"]))
    if c["year_from"] or c["year_to"]:
        parts.append(_years_label(c))
    if c["actor"]:
        parts.append("with %s" % c["actor"])
    if c["stars"]:
        parts.append("%d stars and up" % c["stars"])
    return ", ".join(parts)


def menu():
    c = load()
    while True:
        rows = [
            "[B]Find something to watch[/B]",
            "Type: %s" % ("Movie" if c["media"] == "movie" else "TV show"),
            "Genre: %s" % (", ".join(c["genres"]) or "Any"),
            "When: %s" % _years_label(c),
            "Starring: %s" % (c["actor"] or "Anyone"),
            "Rating: %s" % ("%d stars and up (%.1f+ out of 10)" % (c["stars"], STAR_FLOOR[c["stars"]]) if c["stars"] else "Any"),
            "Look in: %s" % dict(SOURCES)[c["source"]].split(" (")[0],
            "Clear all criteria",
        ]
        choice = common.select("What to Watch", rows)
        if choice < 0:
            save(c)
            return
        if choice == 0:
            save(c)
            return find(c, open_results=True)
        if choice == 1:
            c["media"] = "tv" if c["media"] == "movie" else "movie"
            c["genres"] = []  # genre names differ between movies and TV
        elif choice == 2:
            names = GENRES[c["media"]]
            picked = xbmcgui.Dialog().multiselect("Genres (any of)", names, preselect=[names.index(g) for g in c["genres"] if g in names])
            if picked is not None:
                c["genres"] = [names[i] for i in picked]
        elif choice == 3:
            _pick_years(c)
        elif choice == 4:
            c["actor"] = common.text_input("Starring (actor name, blank for anyone)", c["actor"]).strip()
        elif choice == 5:
            picked = common.select("Minimum rating", ["Any"] + ["%d star%s and up (%.1f+)" % (n, "" if n == 1 else "s", STAR_FLOOR[n]) for n in range(1, 6)], c["stars"])
            if picked >= 0:
                c["stars"] = picked
        elif choice == 6:
            picked = common.select("Look in", [label for _, label in SOURCES], [k for k, _ in SOURCES].index(c["source"]))
            if picked >= 0:
                c["source"] = SOURCES[picked][0]
        elif choice == 7:
            c = dict(DEFAULT, media=c["media"], source=c["source"])


def _pick_years(c):
    this_year = datetime.date.today().year
    decades = list(range(this_year - this_year % 10, 1919, -10))
    rows = ["Any time", "A single year", "A custom range"] + ["%ds" % d for d in decades]
    choice = common.select("When", rows)
    if choice < 0:
        return
    if choice == 0:
        c["year_from"] = c["year_to"] = 0
    elif choice == 1:
        year = _ask_year("Year", c["year_from"] or this_year)
        if year:
            c["year_from"] = c["year_to"] = year
    elif choice == 2:
        first = _ask_year("From year", c["year_from"] or 1990)
        last = _ask_year("To year", c["year_to"] or this_year)
        if first and last:
            c["year_from"], c["year_to"] = min(first, last), max(first, last)
    else:
        c["year_from"], c["year_to"] = decades[choice - 3], decades[choice - 3] + 9


def _ask_year(heading, default):
    value = xbmcgui.Dialog().numeric(0, heading, str(default))
    try:
        year = int(value)
    except (TypeError, ValueError):
        return 0
    return year if 1880 <= year <= 2100 else 0


# -- finding ---------------------------------------------------------------
def find(criteria=None, open_results=False):
    c = criteria or load()
    progress = xbmcgui.DialogProgressBG()
    progress.create("What to Watch", describe(c))
    pool = []
    try:
        if c["source"] in ("library", "both"):
            pool += _from_library(c)
        if c["source"] in ("stream", "both") and common.has_addon(TMDBH):
            pool += _from_tmdb(c)
    finally:
        progress.close()
    seen, unique = set(), []
    for item in pool:
        key = (item["label"].lower(), item.get("year"))
        if key not in seen:
            seen.add(key)
            unique.append(item)
    random.shuffle(unique)
    common.write_json(common.data_file(RESULTS_FILE), {"criteria": describe(c), "items": unique[:POOL_SIZE], "stamp": int(time.time())})
    xbmc.executebuiltin("Skin.SetString(Chameleon.Picker.Label,%s)" % describe(c).replace(",", " /"))
    xbmc.executebuiltin("Skin.SetString(Chameleon.Picker.Stamp,%d)" % int(time.time()))
    if not unique:
        common.ok("Nothing matched: %s.[CR]Try loosening a criterion." % describe(c), "What to Watch")
        return False
    if open_results:
        xbmc.executebuiltin("ActivateWindow(Videos,%s?mode=picks&stamp=%d,return)" % (SELF_URL, int(time.time())))
    return True


def _from_library(c):
    rules = []
    if c["genres"]:
        rules.append({"or": [{"field": "genre", "operator": "contains", "value": g.split(" & ")[0]} for g in c["genres"]]})
    if c["year_from"]:
        rules.append({"field": "year", "operator": "greaterthan", "value": str(c["year_from"] - 1)})
    if c["year_to"]:
        rules.append({"field": "year", "operator": "lessthan", "value": str(c["year_to"] + 1)})
    if c["actor"]:
        rules.append({"field": "actor", "operator": "contains", "value": c["actor"]})
    if c["stars"]:
        rules.append({"field": "rating", "operator": "greaterthan", "value": str(STAR_FLOOR[c["stars"]] - 0.01)})
    params = {"properties": ["title", "year", "rating", "genre", "plot", "art", "file"], "sort": {"method": "random"}, "limits": {"start": 0, "end": POOL_SIZE}}
    if rules:
        params["filter"] = {"and": rules}
    movie = c["media"] == "movie"
    result = common.jsonrpc("VideoLibrary.GetMovies" if movie else "VideoLibrary.GetTVShows", params) or {}
    items = []
    for entry in result.get("movies" if movie else "tvshows", []):
        dbid = entry["movieid"] if movie else entry["tvshowid"]
        items.append({
            "label": entry.get("title") or entry.get("label", ""), "year": entry.get("year", 0), "rating": entry.get("rating", 0),
            "genre": entry.get("genre", []), "plot": entry.get("plot", ""), "art": _clean_art(entry.get("art", {})),
            "file": entry.get("file", "") if movie else "videodb://tvshows/titles/%d/" % dbid,
            "folder": not movie, "mediatype": "movie" if movie else "tvshow", "dbid": dbid, "source": "Library",
        })
    return items


def _person_id(name):
    """Resolve an actor name to a TMDb person id through TMDb Helper's search."""
    path = "plugin://%s/?%s" % (TMDBH, urlencode([("info", "search"), ("tmdb_type", "person"), ("query", name)], quote_via=quote))
    result = common.jsonrpc("Files.GetDirectory", {"directory": path, "media": "video", "properties": ["file"]}) or {}
    for entry in result.get("files", []):
        found = dict(parse_qsl(entry.get("file", "").split("?", 1)[-1])).get("tmdb_id")
        if found:
            return found
    return ""


def _discover_path(c, sort_by, page, person_id=""):
    movie = c["media"] == "movie"
    date = "primary_release_date" if movie else "first_air_date"
    # with_id=True tells TMDb Helper the values are already TMDb ids, so nothing depends on its name lookups
    params = [("info", "discover"), ("tmdb_type", "movie" if movie else "tv"), ("with_id", "True"), ("sort_by", sort_by), ("page", str(page)),
              ("vote_count.gte", "150" if c["stars"] else "25")]
    ids = [str(GENRE_IDS[c["media"]][g]) for g in c["genres"] if g in GENRE_IDS[c["media"]]]
    if ids:
        params.append(("with_genres", "|".join(ids)))  # pipe means "any of" in the TMDb API
    if c["year_from"]:
        params.append(("%s.gte" % date, "%d-01-01" % c["year_from"]))
    if c["year_to"]:
        params.append(("%s.lte" % date, "%d-12-31" % c["year_to"]))
    if person_id:
        params.append(("with_cast", person_id))
    if c["stars"]:
        params.append(("vote_average.gte", str(STAR_FLOOR[c["stars"]])))
    return "plugin://%s/?%s" % (TMDBH, urlencode(params, quote_via=quote))


def _from_tmdb(c):
    movie = c["media"] == "movie"
    if c["actor"] and not movie:
        # TMDb cannot filter TV discovery by cast, so start from the actor's TV credits and filter here
        path = "plugin://%s/?%s" % (TMDBH, urlencode([("info", "stars_in_tvshows"), ("tmdb_type", "person"), ("query", c["actor"])], quote_via=quote))
        return [i for i in _directory(path, c) if _passes(i, c)]
    person_id = ""
    if c["actor"]:
        person_id = _person_id(c["actor"])
        if not person_id:
            common.notify("No actor found for '%s'" % c["actor"])
            return []
    plans = [("popularity.desc", 1), ("vote_count.desc", random.randint(1, 3)), ("popularity.desc", random.randint(2, 6))]
    if c["stars"] >= 4:
        plans[2] = ("vote_average.desc", random.randint(1, 3))
    items = []
    for sort_by, page in plans:
        items += _directory(_discover_path(c, sort_by, page, person_id), c)
    return items


def _passes(item, c):
    if c["year_from"] and (item.get("year") or 0) < c["year_from"]:
        return False
    if c["year_to"] and (item.get("year") or 9999) > c["year_to"]:
        return False
    if c["stars"] and (item.get("rating") or 0) < STAR_FLOOR[c["stars"]]:
        return False
    if c["genres"]:
        have = " ".join(item.get("genre") or []).lower()
        if not any(part.strip().lower() in have for g in c["genres"] for part in g.split("&")):
            return False
    return True


def _directory(path, c):
    result = common.jsonrpc("Files.GetDirectory", {"directory": path, "media": "video", "properties": ["title", "year", "rating", "genre", "plot", "art", "file"]}) or {}
    wanted = "movie" if c["media"] == "movie" else "tvshow"
    items = []
    for entry in result.get("files", []):
        if entry.get("type") not in (wanted, "unknown") or not entry.get("title"):
            continue  # skips paging and menu rows
        if entry.get("type") == "unknown" and not entry.get("year"):
            continue
        items.append({
            "label": entry.get("title"), "year": entry.get("year", 0), "rating": entry.get("rating", 0), "genre": entry.get("genre", []),
            "plot": entry.get("plot", ""), "art": _clean_art(entry.get("art", {})), "file": entry.get("file", ""),
            "folder": entry.get("filetype") == "directory", "mediatype": wanted, "source": "Streaming",
        })
    return items


def _clean_art(art):
    return {k: v for k, v in art.items() if v and k in ("poster", "fanart", "landscape", "thumb", "clearlogo", "banner", "tvshow.poster", "tvshow.fanart")}


# -- serving ---------------------------------------------------------------
def serve(handle, query):
    params = dict(parse_qsl(query.lstrip("?")))
    if params.get("mode") == "providers":
        return serve_providers(handle, params)
    if not params.get("mode"):
        # opened from the add-on browser rather than by a home row: show the Chameleon menu, not an empty list
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        xbmc.executebuiltin("RunScript(%s)" % common.ADDON_ID)
        return
    data = common.read_json(common.data_file(RESULTS_FILE))
    items = list(data.get("items", []))
    random.shuffle(items)
    limit = int(params.get("limit", SHOW))
    media = items[0]["mediatype"] if items else "movie"
    xbmcplugin.setContent(handle, "movies" if media == "movie" else "tvshows")
    xbmcplugin.setPluginCategory(handle, data.get("criteria", "What to Watch"))
    for item in items[:limit]:
        li = xbmcgui.ListItem(item["label"], offscreen=True)
        li.setArt(item.get("art", {}))
        tag = li.getVideoInfoTag()
        tag.setTitle(item["label"])
        tag.setMediaType(item["mediatype"])
        if item.get("year"):
            tag.setYear(int(item["year"]))
        if item.get("rating"):
            tag.setRating(float(item["rating"]))
        if item.get("genre"):
            tag.setGenres(list(item["genre"]))
        if item.get("plot"):
            tag.setPlot(item["plot"])
        if item.get("dbid"):
            tag.setDbId(int(item["dbid"]))
        li.setProperty("chameleon.source", item.get("source", ""))
        if not item["folder"]:
            li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle, item["file"], li, item["folder"])
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# -- Streaming service tiles -------------------------------------------------
# Curated services (alphabetical). Each tile opens Fen Light's own list for that provider.
PROVIDERS = [('Apple TV+', 350, '6uhKBfmtzFqOcLousHwZuzcrScK.jpg', '6uhKBfmtzFqOcLousHwZuzcrScK.jpg'), ('Disney+', 337, '7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg', '7rwgEs15tFwyR9NPQ5vpzxTj19Q.jpg'), ('HBO Max', 384, 'Ajqyt5aNxNGjmF9uOfxArGrdf3X.jpg', 'Ajqyt5aNxNGjmF9uOfxArGrdf3X.jpg'), ('Hulu', 15, 'zxrVdFjIjLqkfnwyghnfywTn3Lh.jpg', 'zxrVdFjIjLqkfnwyghnfywTn3Lh.jpg'), ('Netflix', 8, 't2yyOv40HZeVlLjYsCsPHnWLk4W.jpg', 't2yyOv40HZeVlLjYsCsPHnWLk4W.jpg'), ('Paramount+', 531, 'xbhHHa1YgtpwhC8lb1NQ3ACVcLd.jpg', 'xbhHHa1YgtpwhC8lb1NQ3ACVcLd.jpg'), ('Peacock', 386, '8VCV78prwd9QzZnEm0ReO6bERDa.jpg', '8VCV78prwd9QzZnEm0ReO6bERDa.jpg'), ('Prime Video', 9, 'emthp39XA2YScoYL1p0sdbAH2WA.jpg', 'emthp39XA2YScoYL1p0sdbAH2WA.jpg')]
PROVIDER_ART = "https://image.tmdb.org/t/p/original/%s"


def serve_providers(handle, params):
    """Home row of streaming service tiles. Empty unless the current look turns the tiles on."""
    tv = params.get("type", "movie") != "movie"
    xbmcplugin.setPluginCategory(handle, "Streaming Services")
    if xbmc.getCondVisibility("Skin.HasSetting(Chameleon.ProviderTiles)") or params.get("always"):
        for label, key_id, movie_icon, tv_icon in PROVIDERS:
            if tv:
                path = "plugin://plugin.video.fenlight/?mode=build_tvshow_list&action=tmdb_tv_providers&key_id=%d&name=%s" % (key_id, quote_plus(label))
            else:
                path = "plugin://plugin.video.fenlight/?mode=build_movie_list&action=tmdb_movies_providers&key_id=%d&name=%s" % (key_id, quote_plus(label))
            li = xbmcgui.ListItem(label, offscreen=True)
            li.setArt({"icon": PROVIDER_ART % (tv_icon if tv else movie_icon)})
            li.setProperty("chameleon.tile", "provider")
            xbmcplugin.addDirectoryItem(handle, path, li, True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# -- TMDb Helper player ----------------------------------------------------
def install_fenlight_player(quiet=False):
    folder = xbmcvfs.translatePath("special://profile/addon_data/%s/players/" % TMDBH)
    target = os.path.join(folder, "fenlight.json")
    existing = [n for n in (os.listdir(folder) if os.path.isdir(folder) else []) if "fen" in n.lower()]
    if existing and not quiet and not common.confirm("A Fen player file already exists (%s). Add Chameleon's fenlight.json anyway?" % ", ".join(existing)):
        return False
    common.ensure_dir(folder)
    with open(os.path.join(common.ADDON_PATH, "resources", "players", "fenlight.json"), "r", encoding="utf-8") as handle:
        player = json.load(handle)
    common.write_json(target, player)
    try:  # make Fen Light the default so TMDb Helper plays straight away instead of asking each time
        import xbmcaddon

        tmdbh = xbmcaddon.Addon(TMDBH)
        tmdbh.setSetting("default_player_movies", "fenlight.json play_movie")
        tmdbh.setSetting("default_player_episodes", "fenlight.json play_episode")
    except Exception as exc:
        common.log("could not set the default TMDb Helper player: %r" % exc)
    if not quiet:
        common.ok("Fen Light player installed for TMDb Helper. Streaming picks will offer Fen Light when you press play.")
    return True
