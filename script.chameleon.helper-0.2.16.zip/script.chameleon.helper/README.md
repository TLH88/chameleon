# Chameleon Helper 0.1.0

Companion add-on for the Chameleon skin.

- **Presets and colours**: applies preset JSON files from the skin, generates colors/Chameleon.xml from five base
  colours, and rebuilds the highlight gradient textures.
- **Accounts**: sign in once to Trakt and Real-Debrid, enter Premiumize, YouTube and metadata API keys once, and push
  them to installed add-ons. A background pass keeps Trakt tokens aligned (newest token wins, then it is re-pushed).
- **What to Watch**: pick type, genres, years, actor and a minimum star rating; get a shuffled list from TMDb
  (through TMDb Helper) and/or your Kodi library. Also served as a widget at
  `plugin://script.chameleon.helper/?mode=picks`.

## Connectors
One JSON file per add-on in resources/connectors. To support another add-on, drop a file with the same shape into
`addon_data/script.chameleon.helper/connectors/`. `"store": {"type": "settings"}` covers any add-on that keeps
credentials in normal Kodi settings; the Fen Light file shows the sqlite form.

## Where credentials live
`addon_data/script.chameleon.helper/accounts.json`, plain text, the same as every Kodi add-on stores them.
Anyone with access to the Kodi profile folder can read it.
