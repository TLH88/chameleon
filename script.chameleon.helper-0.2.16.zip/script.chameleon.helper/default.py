# -*- coding: utf-8 -*-
import os
import sys

import xbmc

# Show Kodi's busy spinner straight away. The first run after an install compiles every module, which can
# take many seconds, and without this the click looks like it did nothing. Dialogs close it (common.py).
xbmc.executebuiltin("ActivateWindow(busydialognocancel)")

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

try:
    from chameleon import router  # noqa: E402

    if __name__ == "__main__":
        router.run(sys.argv[1:])
finally:
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
