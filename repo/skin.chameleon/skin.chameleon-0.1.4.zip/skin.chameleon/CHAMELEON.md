# Chameleon 0.1.0

A personal fork of Arctic Horizon 2.1 by DeFiNiek, which continues Arctic Horizon 2 by jurialmunkey.
All credit for the underlying skin goes to them. Licensed CC BY-NC-SA 4.0 like the original: share alike, with
attribution, non-commercial only.

## What this fork changes
- Skin id and name (installs alongside Arctic Horizon 2, with its own settings).
- New "Chameleon" section at the top of Skin Settings: presets, colours, accounts, home editor.
- extras/presets/*.json: look presets. tracked.json lists the settings a preset controls.
- shortcuts/: default home menu and widgets for Fen Light, Trakt, What to Watch and the NAS library.
- 1080i/Includes_Home.xml: text menu focus pill uses the highlight gradient again (2.1 drew white text on a white pill).
- Requires script.chameleon.helper.

## Adding your own preset
Copy any file in extras/presets, change the name, colours (AARRGGBB), strings and bools, and it appears in the
preset list. Or set things up by hand and use "Save current look as a preset".
