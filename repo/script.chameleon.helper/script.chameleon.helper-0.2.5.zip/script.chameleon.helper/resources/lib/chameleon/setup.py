# -*- coding: utf-8 -*-
"""First-run setup wizard.

One add-on (this helper) is installed by hand. Everything else happens here: repositories, add-ons,
account sign-in, automatic configuration, and choosing a look. Every step can be re-run and skips
work that is already done, so the wizard is safe to open again later.
"""
import os
import re
import shutil
import time
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

from . import common

# Where Chameleon's own add-ons are published. Change the two names if the GitHub repository moves.
GITHUB_USER = "TLH88"
GITHUB_REPO = "chameleon"
REPO_BASE = "https://raw.githubusercontent.com/%s/%s/main/repo" % (GITHUB_USER, GITHUB_REPO)
REPO_ADDON = "repository.chameleon"

SKIN = "skin.chameleon"
FENLIGHT = "plugin.video.fenlight"

# Installed through Kodi's own installer so dependencies and platform builds are resolved by Kodi.
# Third-party repositories some of those add-ons live in: (repository id, page that lists its zip)
EXTRA_REPOS = [
    ("repository.jurialmunkey", "jurialmunkey repository", "https://jurialmunkey.github.io/repository.jurialmunkey/"),
    ("repository.cocoscrapers", "CocoScrapers repository", "https://cocojoe2411.github.io/"),
]

KODI_REPO_ADDONS = [
    ("script.module.requests", "Requests"),
    ("plugin.video.themoviedb.helper", "TMDb Helper"),
    ("script.skinshortcuts", "Skin Shortcuts"),
    ("script.skinvariables", "Skin Variables"),
    ("script.texturemaker", "Texture Maker"),
    ("inputstream.adaptive", "InputStream Adaptive"),
    ("plugin.video.youtube", "YouTube (trailers)"),
    ("script.module.cocoscrapers", "CocoScrapers (source finder for Fen Light)"),
]

HOME_ADDONS = xbmcvfs.translatePath("special://home/addons/")
PACKAGES = os.path.join(HOME_ADDONS, "packages")
STATE_FILE = "setup.json"


# -- state -------------------------------------------------------------------
def state():
    return common.read_json(common.data_file(STATE_FILE), {}) or {}


def save_state(**fields):
    data = state()
    data.update(fields)
    common.write_json(common.data_file(STATE_FILE), data)
    return data


def needs_first_run():
    """True on a box where the wizard has never finished and Chameleon is not already in use."""
    if state().get("done"):
        return False
    if xbmc.getSkinDir() == SKIN:
        save_state(done=True, note="skin already active")  # an existing install: never interrupt it
        return False
    return True


def _base(key, default):
    """setup.json may override where things are downloaded from (testing, forks, mirrors)."""
    return (state().get(key) or default).rstrip("/\\")


# -- low level installers ----------------------------------------------------
def _has(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def _enabled(addon_id):
    return xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % addon_id)


def _ready(addon_id):
    """Installed and switched on (System.HasAddon alone is also true for a switched-off add-on)."""
    return _has(addon_id) and _enabled(addon_id)


def _enable(addon_id):
    common.jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})


def _answer_install_dialogs():
    """Kodi asks before installing an add-on and may list extra add-ons it will bring along.
    Both are answered Yes/OK so the user is not walked through a confirmation per add-on."""
    if xbmc.getCondVisibility("Window.IsVisible(yesnodialog)"):
        xbmc.executebuiltin("SendClick(yesnodialog,11)")
        return True
    if xbmc.getCondVisibility("Window.IsVisible(selectdialog)"):
        xbmc.executebuiltin("SendClick(selectdialog,5)")
        return True
    return False


def install_from_kodi(addon_id, timeout=240, cancelled=None):
    """Install (or just enable) an add-on from any repository Kodi already knows about.
    Kodi's own installer does the work, so dependencies and the right build for this device come with it."""
    if _has(addon_id):
        if not _enabled(addon_id):
            _enable(addon_id)
        return True
    monitor = xbmc.Monitor()
    started = time.time()
    asked = 0
    seen_activity = False
    while time.time() - started < timeout:
        if cancelled and cancelled():
            return False
        if not asked or (not seen_activity and time.time() - asked > 25 and time.time() - started < 90):
            # nothing happened: on a fresh box Kodi may not have read its repositories yet
            if asked:
                xbmc.executebuiltin("UpdateAddonRepos", True)
                monitor.waitForAbort(10)
            xbmc.executebuiltin("InstallAddon(%s)" % addon_id)
            asked = time.time()
        if monitor.waitForAbort(1):
            return False
        if _answer_install_dialogs():
            seen_activity = True
        if xbmc.getCondVisibility("Window.IsVisible(okdialog)"):
            # Kodi reports a failed install (for example a missing dependency) with an OK box. Close it and
            # move on, otherwise the wizard would sit behind it until the timeout.
            reason = xbmc.getInfoLabel("Control.GetLabel(9)") or "Kodi reported a failed install"
            xbmc.executebuiltin("Dialog.Close(okdialog,true)")
            common.log("setup: %s failed: %s" % (addon_id, reason))
            monitor.waitForAbort(1)
            return _has(addon_id)
        if xbmc.getCondVisibility("Window.IsVisible(extendedprogressdialog)"):
            seen_activity = True
        if _has(addon_id):
            if not _enabled(addon_id):
                _enable(addon_id)
                monitor.waitForAbort(1)
            return True
        if not seen_activity and time.time() - started > 90:
            break  # Kodi never offered it: no repository on this box lists the add-on
    common.log("setup: could not install %s" % addon_id)
    return _has(addon_id)


def _is_local(location):
    return not re.match(r"^https?://", location or "")


def _join(base, *parts):
    return os.path.join(base, *parts) if _is_local(base) else "/".join([base] + list(parts))


def _read_text(location):
    if _is_local(location):
        with open(location, "r", encoding="utf-8") as handle:
            return handle.read()
    import requests

    response = requests.get(location, timeout=30)
    response.raise_for_status()
    return response.text


def _download(url, target):
    common.ensure_dir(os.path.dirname(target))
    if _is_local(url):  # a folder on this device (testing, or an offline bundle)
        shutil.copyfile(url, target)
        return target
    import requests

    with requests.get(url, stream=True, timeout=60) as response:
        response.raise_for_status()
        with open(target, "wb") as handle:
            for chunk in response.iter_content(1024 * 256):
                if chunk:
                    handle.write(chunk)
    return target


def install_zip(url, addon_id, replace=False):
    """Unpack an add-on zip straight into the add-ons folder and switch it on. Used for add-ons that live
    outside any repository Kodi knows yet: our own repository add-on, and Fen Light."""
    if _has(addon_id) and not replace:
        if not _enabled(addon_id):
            _enable(addon_id)
        return True
    zip_path = _download(url, os.path.join(PACKAGES, os.path.basename(url.replace("\\", "/").split("?")[0])))
    from . import silent

    silent.extract_zip(zip_path, HOME_ADDONS, addon_id)
    try:
        os.remove(zip_path)
    except OSError:
        pass
    xbmc.executebuiltin("UpdateLocalAddons", True)
    monitor = xbmc.Monitor()
    monitor.waitForAbort(2)
    for _ in range(20):  # a freshly unpacked add-on is off until it is switched on
        if _ready(addon_id):
            break
        _enable(addon_id)
        if monitor.waitForAbort(1.5):
            break
    return _ready(addon_id)


def _repo_listing():
    """addon id -> version, read from our repository's addons.xml."""
    text = _read_text(_join(_base("repo_base", REPO_BASE), "addons.xml"))
    return dict(re.findall(r'<addon[^>]*?id="([^"]+)"[^>]*?version="([^"]+)"', text))


def skin_dependencies():
    """Add-on ids the skin needs, read from our repository listing. Kodi only pulls a dependency
    automatically from the same repository or its official one, so anything that lives in another
    third-party repository has to be installed by name before the skin."""
    text = _read_text(_join(_base("repo_base", REPO_BASE), "addons.xml"))
    block = re.search(r'<addon[^>]*?id="%s".*?</addon>' % re.escape(SKIN), text, flags=re.S)
    if not block:
        return []
    found = re.findall(r'<import[^>]*?addon="([^"]+)"', block.group(0))
    return [a for a in found if not a.startswith("xbmc.")]


def install_chameleon_repo():
    if _has(REPO_ADDON):
        if not _enabled(REPO_ADDON):
            _enable(REPO_ADDON)
    else:
        version = _repo_listing().get(REPO_ADDON)
        if not version:
            raise ValueError("The Chameleon repository listing could not be read.")
        install_zip(_join(_base("repo_base", REPO_BASE), REPO_ADDON, "%s-%s.zip" % (REPO_ADDON, version)), REPO_ADDON)
    xbmc.executebuiltin("UpdateAddonRepos", True)
    xbmc.Monitor().waitForAbort(8)  # let Kodi read the new repository before asking it for add-ons
    return _has(REPO_ADDON)


def install_extra_repo(repo_id, index_url):
    """Install a third-party repository add-on from the page that publishes its zip."""
    if _has(repo_id):
        if not _enabled(repo_id):
            _enable(repo_id)
        return True
    page = _read_text(index_url)
    names = re.findall(r'href="(%s-[0-9][^"]*\.zip)"' % re.escape(repo_id), page)
    if not names:
        raise ValueError("No %s zip is listed at %s" % (repo_id, index_url))
    return install_zip(index_url.rstrip("/") + "/" + names[-1], repo_id)


def install_fenlight():
    """Fen Light's own download source no longer exists, so a copy is published in the Chameleon repository
    and installed through Kodi like any other add-on."""
    return install_from_kodi(FENLIGHT, timeout=300)


# -- automatic configuration --------------------------------------------------
def configure_kodi():
    """Kodi settings Chameleon expects. No prompts."""
    options = common.read_json(common.data_file("options.json"), {}) or {}
    options.setdefault("disable_mouse", True)
    common.write_json(common.data_file("options.json"), options)
    common.jsonrpc("Settings.SetSettingValue", {"setting": "input.enablemouse", "value": False})
    return True


def configure_players():
    from . import picker

    return bool(picker.install_fenlight_player(quiet=True))


def apply_fenlight_tweaks():
    from . import fenlight_tweaks

    return fenlight_tweaks.apply_all()


def switch_skin():
    if xbmc.getSkinDir() == SKIN:
        return True
    common.jsonrpc("Settings.SetSettingValue", {"setting": "lookandfeel.skin", "value": SKIN})
    monitor = xbmc.Monitor()
    answered = False
    for second in range(45):
        if monitor.waitForAbort(1):
            return False
        if xbmc.getCondVisibility("Window.IsVisible(yesnodialog)"):
            # Kodi asks "keep this change?" a moment after the new skin loads; unanswered, it reverts
            xbmc.executebuiltin("SendClick(yesnodialog,11)")
            answered = True
            continue
        if xbmc.getSkinDir() == SKIN and (answered or second >= 20):
            monitor.waitForAbort(2)
            return xbmc.getSkinDir() == SKIN
    return xbmc.getSkinDir() == SKIN


# -- the wizard ----------------------------------------------------------------
class Progress(object):
    def __init__(self, heading):
        common.not_busy()
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create(heading, "Starting")

    def update(self, percent, message):
        self.dialog.update(int(percent), message)

    def cancelled(self):
        return self.dialog.iscanceled()

    def close(self):
        self.dialog.close()


LABELS = dict(KODI_REPO_ADDONS)
LABELS.update({FENLIGHT: "Fen Light", SKIN: "Chameleon skin"})


def _install_step(results):
    """Repositories first, then everything else in one quiet pass (no per-add-on questions). Anything the
    quiet installer cannot do, such as add-ons with compiled parts, falls back to Kodi's own installer."""
    progress = Progress("Chameleon setup: installing")
    cancelled = lambda: progress.cancelled()  # noqa: E731

    def record(label, job):
        try:
            ok = bool(job())
            note = "" if ok else "did not install"
        except Exception as exc:  # one failure must not stop the rest
            ok, note = False, str(exc)
            common.log("setup: %s failed: %r" % (label, exc))
        results.append((label, ok, note))
        return ok

    try:
        repos = [(label, lambda r=repo_id, u=url: install_extra_repo(r, u)) for repo_id, label, url in EXTRA_REPOS]
        repos.append(("Chameleon repository", install_chameleon_repo))
        for index, (label, job) in enumerate(repos):
            if cancelled():
                results.append(("Install", False, "cancelled"))
                return False
            progress.update(10.0 * index / len(repos), "Adding the %s" % label)
            record(label, job)

        from . import silent

        targets = [addon_id for addon_id, _ in KODI_REPO_ADDONS] + [FENLIGHT]
        try:
            targets += [a for a in skin_dependencies() if a not in targets]
        except Exception as exc:
            common.log("setup: could not read the skin requirements: %r" % exc)
        targets.append(SKIN)
        progress.update(10, "Working out what is needed")
        leftover_off = [n for n in os.listdir(HOME_ADDONS)
                        if os.path.isfile(os.path.join(HOME_ADDONS, n, "addon.xml")) and not _ready(n)]
        if leftover_off:
            silent.enable_all(leftover_off, seconds=20)

        def on_progress(number, total, addon_id):
            progress.update(12 + 80.0 * number / max(total, 1),
                            "Installing %s[CR](%d of %d)" % (LABELS.get(addon_id, addon_id), number + 1, total))

        try:
            _, compiled, failures = silent.install(targets, on_progress, cancelled)
        except Exception as exc:
            common.log("setup: quiet install failed, using Kodi's installer: %r" % exc)
            compiled, failures = [], {}
        if cancelled():
            results.append(("Install", False, "cancelled"))
            return False
        # Kodi's installer handles what is left: compiled add-ons, and anything the quiet pass missed
        leftovers = [a for a in targets if not _ready(a)] + [a for a in compiled if a not in targets and not _ready(a)]
        for index, addon_id in enumerate(leftovers):
            progress.update(92 + 8.0 * index / max(len(leftovers), 1), "Installing %s" % LABELS.get(addon_id, addon_id))
            install_from_kodi(addon_id, timeout=900 if addon_id == SKIN else 240, cancelled=cancelled)
        for addon_id in targets:
            if addon_id in LABELS:
                ok = bool(_ready(addon_id))
                results.append((LABELS[addon_id].split(" (")[0], ok, "" if ok else failures.get(addon_id, "did not install")))
        hidden = [a for a in targets if a not in LABELS and not _ready(a)]
        if hidden:
            results.append(("Skin requirements", False, "missing: " + ", ".join(hidden)))
    finally:
        progress.close()
    return True


def _config_step(results):
    progress = Progress("Chameleon setup: configuring")
    jobs = [("Fen Light tweaks (sort orders and fixes)", apply_fenlight_tweaks),
            ("Fen Light as the default player", configure_players),
            ("Kodi options", configure_kodi)]
    try:
        for index, (label, job) in enumerate(jobs):
            progress.update(100.0 * index / len(jobs), label)
            try:
                ok = bool(job())
                note = "" if ok else "not applied"
            except Exception as exc:
                ok, note = False, str(exc)
                common.log("setup: %s failed: %r" % (label, exc))
            results.append((label, ok, note))
    finally:
        progress.close()


def _accounts_step(results):
    from . import accounts

    def premiumize():
        # Fen Light can show a pairing code (premiumize.me/device). Typing an API key is only the fallback.
        if accounts.delegate_connector("pm"):
            return accounts.delegated_sign_in("pm")
        return accounts.pm_set_key()

    steps = [("trakt", "Trakt", accounts.trakt_sign_in),
             ("pm", "Premiumize", premiumize)]
    for service, label, sign_in in steps:
        if accounts.is_signed_in(service):
            results.append((label + " sign-in", True, "already signed in"))
            continue
        if not common.confirm("Sign in to %s now? You will get a short code to enter on your phone or computer.[CR][CR]You can skip this and do it later from the Chameleon menu." % label,
                              "Chameleon setup: accounts"):
            results.append((label + " sign-in", False, "skipped"))
            continue
        try:
            sign_in()
        except Exception as exc:
            common.log("setup: %s sign-in failed: %r" % (label, exc))
        results.append((label + " sign-in", accounts.is_signed_in(service),
                        "" if accounts.is_signed_in(service) else "not completed"))
    try:
        accounts.push_all()
    except Exception as exc:
        common.log("setup: account push failed: %r" % exc)


def _look_step(results):
    from . import presets

    ok = switch_skin()
    results.append(("Switch to the Chameleon skin", ok, "" if ok else "skin not active"))
    if not ok:
        return
    xbmc.Monitor().waitForAbort(4)
    chosen = presets.choose()
    results.append(("Choose a look", bool(chosen), "" if chosen else "kept the default look"))


def _summary(results):
    """A list with a Close button, rather than a text page that can only be left with Back."""
    lines = []
    for label, ok, note in results:
        mark = "[COLOR FF4CAF50]Done[/COLOR]" if ok else "[COLOR FFFFB300]Not done[/COLOR]"
        lines.append("%s   %s%s" % (mark, label, (" (%s)" % note) if note else ""))
    lines.append("[B]Close[/B]")
    not_done = len([1 for _, ok, _ in results if not ok])
    heading = "Setup finished" if not not_done else "Setup finished, %d item%s to revisit" % (not_done, "" if not_done == 1 else "s")
    xbmcgui.Dialog().select(heading, lines, preselect=len(lines) - 1)


def run(first_run=False):
    intro = ("This installs what Chameleon needs, signs you in to Trakt and Premiumize, sets up playback and "
             "lets you pick a look.[CR][CR]It takes a few minutes and needs internet. Start now?")
    if not common.confirm(intro, "Chameleon setup"):
        if first_run:
            save_state(postponed=int(time.time()))
            common.ok("No problem. You can start it any time from Add-ons, Chameleon Helper, Run setup wizard.")
        return False
    results = []
    if _install_step(results):
        _accounts_step(results)
        _config_step(results)
        _look_step(results)
    save_state(done=True, finished=int(time.time()),
               results=[[label, ok, note] for label, ok, note in results])
    _summary(results)
    return True
