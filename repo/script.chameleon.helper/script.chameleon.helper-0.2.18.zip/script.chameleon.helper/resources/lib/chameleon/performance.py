# -*- coding: utf-8 -*-
"""Speed settings sized to the box Kodi is running on.

Three things, all of them Kodi's own settings:
  * the streaming buffer (Settings, Services, Caching), sized to the memory the box has;
  * on LibreELEC, menus drawn at 1080p even on a 4K screen (video still plays at full resolution);
  * on small-memory boxes, artwork cached at a smaller size (advancedsettings.xml).
"""
import os
import re
import xml.etree.ElementTree as ET

import xbmc
import xbmcvfs

from . import common

# Kodi takes about three times the buffer size in memory, so each step leaves the rest of the box room to work
BUFFER_BY_MEMORY = ((1200, 32), (2500, 64), (5000, 128), (10000, 256))
BUFFER_LARGEST = 512
SMALL_MEMORY = 2500  # MB; at or under this, artwork is cached smaller
SMALL_ARTWORK = {"imageres": "540", "fanartres": "720"}
GUI_LIMIT_1080 = 3  # videoscreen.limitguisize: 0 unlimited, 1 720, 2 1080/720, 3 1080, 4 unlimited/1080


def total_memory_mb():
    match = re.search(r"(\d+)", xbmc.getInfoLabel("System.Memory(total)") or "")
    if match and int(match.group(1)) > 0:
        return int(match.group(1))
    try:
        with open("/proc/meminfo", "r") as handle:
            for line in handle:
                if line.startswith("MemTotal:"):
                    return int(line.split()[1]) // 1024
    except Exception:
        pass
    return 0


def buffer_for(memory_mb):
    if not memory_mb:
        return 64  # memory unknown: a modest size that is safe anywhere
    for limit, size in BUFFER_BY_MEMORY:
        if memory_mb <= limit:
            return size
    return BUFFER_LARGEST


def _get(setting):
    result = common.jsonrpc("Settings.GetSettingValue", {"setting": setting})
    return None if not isinstance(result, dict) else result.get("value")


def _set(setting, value):
    if _get(setting) is None:
        return False  # this Kodi does not have the setting
    if _get(setting) == value:
        return True
    common.jsonrpc("Settings.SetSettingValue", {"setting": setting, "value": value})
    return _get(setting) == value


def _advanced_path():
    return xbmcvfs.translatePath("special://profile/advancedsettings.xml")


def _artwork_now():
    try:
        root = ET.parse(_advanced_path()).getroot()
    except Exception:
        return {}
    return {tag: (root.findtext(tag) or "").strip() for tag in SMALL_ARTWORK if root.find(tag) is not None}


def _set_artwork(values):
    """Set or clear only our two entries; everything else in the file is kept as it is."""
    path = _advanced_path()
    try:
        tree = ET.parse(path)
        root = tree.getroot()
    except Exception:
        if os.path.isfile(path) and os.path.getsize(path) > 0:
            return False  # a file is there but cannot be read: leave it alone
        root = ET.Element("advancedsettings")
        tree = ET.ElementTree(root)
    changed = False
    for tag in SMALL_ARTWORK:
        node = root.find(tag)
        wanted = values.get(tag)
        if wanted is None:
            if node is not None and (node.text or "").strip() == SMALL_ARTWORK[tag]:
                root.remove(node)  # only take back a value we would have written ourselves
                changed = True
        elif node is None:
            ET.SubElement(root, tag).text = wanted
            changed = True
        elif (node.text or "").strip() != wanted:
            node.text = wanted
            changed = True
    if changed:
        tree.write(path, encoding="utf-8", xml_declaration=False)
    return True


def plan():
    from . import setup

    memory = total_memory_mb()
    return {
        "memory": memory,
        "buffer": buffer_for(memory),
        "limit_gui": setup.is_libreelec(),
        "artwork": dict(SMALL_ARTWORK) if memory and memory <= SMALL_MEMORY else {},
    }


def state():
    """(everything matches the plan, short description). Changes nothing."""
    wanted = plan()
    parts, ok = [], True
    buffer_now = _get("filecache.memorysize")
    if buffer_now is None:
        parts.append("no buffer setting on this Kodi")
    else:
        ok = ok and buffer_now == wanted["buffer"] and _get("filecache.readfactor") == 0
        parts.append("buffer %s MB" % buffer_now)
    if wanted["limit_gui"]:
        limit = _get("videoscreen.limitguisize")
        ok = ok and limit in (1, 2, 3)
        parts.append("menus at 1080p" if limit in (2, 3) else "menus at 720p" if limit == 1 else "menus at screen size")
    artwork = _artwork_now()
    if wanted["artwork"]:
        ok = ok and all(artwork.get(k) == v for k, v in wanted["artwork"].items())
        parts.append("smaller artwork")
    memory = "%.1f GB memory" % (wanted["memory"] / 1024.0) if wanted["memory"] else "memory unknown"
    return ok, "%s: %s" % (memory, ", ".join(parts))


def apply():
    """Returns (ok, restart_needed)."""
    wanted = plan()
    ok, restart = True, False
    if _get("filecache.memorysize") is not None:
        ok = _set("filecache.memorysize", wanted["buffer"]) and ok
        ok = _set("filecache.readfactor", 0) and ok  # 0 is "adaptive": Kodi reads ahead as fast as the line allows
    if wanted["limit_gui"] and _get("videoscreen.limitguisize") not in (1, 2, 3):  # an existing limit is left as chosen
        ok = _set("videoscreen.limitguisize", GUI_LIMIT_1080) and ok
        restart = True
    before = _artwork_now()
    ok = _set_artwork(wanted["artwork"]) and ok
    restart = restart or before != _artwork_now()
    common.log("performance: memory %s MB, buffer %s MB, limit menus %s, artwork %s, ok %s"
               % (wanted["memory"], wanted["buffer"], wanted["limit_gui"], wanted["artwork"] or "Kodi default", ok))
    return ok, restart
