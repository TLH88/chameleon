# -*- coding: utf-8 -*-
"""First-run setup wizard.

One add-on (this helper) is installed by hand. Everything else happens here: repositories, add-ons,
account sign-in, automatic configuration, and choosing a look. Every step can be re-run and skips
work that is already done, so the wizard is safe to open again later.
"""
import os
import re
import shutil
import time
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

from . import common

# Where Chameleon's own add-ons are published. Change the two names if the GitHub repository moves.
GITHUB_USER = "TLH88"
GITHUB_REPO = "chameleon"
REPO_BASE = "https://raw.githubusercontent.com/%s/%s/main/repo" % (GITHUB_USER, GITHUB_REPO)
REPO_ADDON = "repository.chameleon"

SKIN = "skin.chameleon"
FENLIGHT = "plugin.video.fenlight"
# Fen Light publishes a version file and zips in one folder; this is the same place its own updater uses.
FENLIGHT_BASE = "https://github.com/Tikipeter/tikipeter.github.io/raw/main/packages"

# Installed through Kodi's own installer so dependencies and platform builds are resolved by Kodi.
KODI_REPO_ADDONS = [
    ("script.module.requests", "Requests"),
    ("plugin.video.themoviedb.helper", "TMDb Helper"),
    ("script.skinshortcuts", "Skin Shortcuts"),
    ("script.skinvariables", "Skin Variables"),
    ("script.texturemaker", "Texture Maker"),
    ("inputstream.adaptive", "InputStream Adaptive"),
]

HOME_ADDONS = xbmcvfs.translatePath("special://home/addons/")
PACKAGES = os.path.join(HOME_ADDONS, "packages")
STATE_FILE = "setup.json"


# -- state -------------------------------------------------------------------
def state():
    return common.read_json(common.data_file(STATE_FILE), {}) or {}


def save_state(**fields):
    data = state()
    data.update(fields)
    common.write_json(common.data_file(STATE_FILE), data)
    return data


def needs_first_run():
    """True on a box where the wizard has never finished and Chameleon is not already in use."""
    if state().get("done"):
        return False
    if xbmc.getSkinDir() == SKIN:
        save_state(done=True, note="skin already active")  # an existing install: never interrupt it
        return False
    return True


def _base(key, default):
    """setup.json may override where things are downloaded from (testing, forks, mirrors)."""
    return (state().get(key) or default).rstrip("/\\")


# -- low level installers ----------------------------------------------------
def _has(addon_id):
    return xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id)


def _enabled(addon_id):
    return xbmc.getCondVisibility("System.AddonIsEnabled(%s)" % addon_id)


def _enable(addon_id):
    common.jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})


def _answer_install_dialogs():
    """Kodi asks before installing an add-on and may list extra add-ons it will bring along.
    Both are answered Yes/OK so the user is not walked through a confirmation per add-on."""
    if xbmc.getCondVisibility("Window.IsVisible(yesnodialog)"):
        xbmc.executebuiltin("SendClick(yesnodialog,11)")
        return True
    if xbmc.getCondVisibility("Window.IsVisible(selectdialog)"):
        xbmc.executebuiltin("SendClick(selectdialog,5)")
        return True
    return False


def install_from_kodi(addon_id, timeout=240, cancelled=None):
    """Install (or just enable) an add-on from any repository Kodi already knows about.
    Kodi's own installer does the work, so dependencies and the right build for this device come with it."""
    if _has(addon_id):
        if not _enabled(addon_id):
            _enable(addon_id)
        return True
    monitor = xbmc.Monitor()
    started = time.time()
    asked = 0
    seen_activity = False
    while time.time() - started < timeout:
        if cancelled and cancelled():
            return False
        if not asked or (not seen_activity and time.time() - asked > 25 and time.time() - started < 90):
            # nothing happened: on a fresh box Kodi may not have read its repositories yet
            if asked:
                xbmc.executebuiltin("UpdateAddonRepos", True)
                monitor.waitForAbort(10)
            xbmc.executebuiltin("InstallAddon(%s)" % addon_id)
            asked = time.time()
        if monitor.waitForAbort(1):
            return False
        if _answer_install_dialogs():
            seen_activity = True
        if xbmc.getCondVisibility("Window.IsVisible(extendedprogressdialog)"):
            seen_activity = True
        if _has(addon_id):
            if not _enabled(addon_id):
                _enable(addon_id)
            return True
        if not seen_activity and time.time() - started > 90:
            break  # Kodi never offered it: no repository on this box lists the add-on
    common.log("setup: could not install %s" % addon_id)
    return _has(addon_id)


def _is_local(location):
    return not re.match(r"^https?://", location or "")


def _join(base, *parts):
    return os.path.join(base, *parts) if _is_local(base) else "/".join([base] + list(parts))


def _read_text(location):
    if _is_local(location):
        with open(location, "r", encoding="utf-8") as handle:
            return handle.read()
    import requests

    response = requests.get(location, timeout=30)
    response.raise_for_status()
    return response.text


def _download(url, target):
    common.ensure_dir(os.path.dirname(target))
    if _is_local(url):  # a folder on this device (testing, or an offline bundle)
        shutil.copyfile(url, target)
        return target
    import requests

    with requests.get(url, stream=True, timeout=60) as response:
        response.raise_for_status()
        with open(target, "wb") as handle:
            for chunk in response.iter_content(1024 * 256):
                if chunk:
                    handle.write(chunk)
    return target


def install_zip(url, addon_id, replace=False):
    """Unpack an add-on zip straight into the add-ons folder and switch it on. Used for add-ons that live
    outside any repository Kodi knows yet: our own repository add-on, and Fen Light."""
    if _has(addon_id) and not replace:
        if not _enabled(addon_id):
            _enable(addon_id)
        return True
    zip_path = _download(url, os.path.join(PACKAGES, os.path.basename(url.replace("\\", "/").split("?")[0])))
    with zipfile.ZipFile(zip_path) as archive:
        names = archive.namelist()
        if not names or not names[0].startswith(addon_id + "/"):
            raise ValueError("%s does not contain %s" % (os.path.basename(zip_path), addon_id))
        target = os.path.join(HOME_ADDONS, addon_id)
        if replace and os.path.isdir(target):
            shutil.rmtree(target, ignore_errors=True)
        archive.extractall(HOME_ADDONS)
    try:
        os.remove(zip_path)
    except OSError:
        pass
    xbmc.executebuiltin("UpdateLocalAddons", True)
    monitor = xbmc.Monitor()
    for _ in range(30):
        if _has(addon_id) or monitor.waitForAbort(1):
            break
    _enable(addon_id)
    monitor.waitForAbort(1)
    return _has(addon_id)


def _repo_listing():
    """addon id -> version, read from our repository's addons.xml."""
    text = _read_text(_join(_base("repo_base", REPO_BASE), "addons.xml"))
    return dict(re.findall(r'<addon[^>]*?id="([^"]+)"[^>]*?version="([^"]+)"', text))


def install_chameleon_repo():
    if _has(REPO_ADDON):
        if not _enabled(REPO_ADDON):
            _enable(REPO_ADDON)
    else:
        version = _repo_listing().get(REPO_ADDON)
        if not version:
            raise ValueError("The Chameleon repository listing could not be read.")
        install_zip(_join(_base("repo_base", REPO_BASE), REPO_ADDON, "%s-%s.zip" % (REPO_ADDON, version)), REPO_ADDON)
    xbmc.executebuiltin("UpdateAddonRepos", True)
    xbmc.Monitor().waitForAbort(8)  # let Kodi read the new repository before asking it for add-ons
    return _has(REPO_ADDON)


def fenlight_online_version():
    return _read_text(_join(_base("fenlight_base", FENLIGHT_BASE), "fen_light_version")).strip()


def install_fenlight():
    if _has(FENLIGHT):
        if not _enabled(FENLIGHT):
            _enable(FENLIGHT)
        return True
    version = fenlight_online_version()
    if not re.match(r"^[0-9][0-9.]*$", version):
        raise ValueError("Fen Light's version could not be read.")
    return install_zip(_join(_base("fenlight_base", FENLIGHT_BASE), "%s-%s.zip" % (FENLIGHT, version)), FENLIGHT)


# -- automatic configuration --------------------------------------------------
def configure_kodi():
    """Kodi settings Chameleon expects. No prompts."""
    options = common.read_json(common.data_file("options.json"), {}) or {}
    options.setdefault("disable_mouse", True)
    common.write_json(common.data_file("options.json"), options)
    common.jsonrpc("Settings.SetSettingValue", {"setting": "input.enablemouse", "value": False})
    return True


def configure_players():
    from . import picker

    return bool(picker.install_fenlight_player(quiet=True))


def apply_fenlight_tweaks():
    from . import fenlight_tweaks

    return fenlight_tweaks.apply_all()


def switch_skin():
    if xbmc.getSkinDir() == SKIN:
        return True
    common.jsonrpc("Settings.SetSettingValue", {"setting": "lookandfeel.skin", "value": SKIN})
    monitor = xbmc.Monitor()
    answered = False
    for second in range(45):
        if monitor.waitForAbort(1):
            return False
        if xbmc.getCondVisibility("Window.IsVisible(yesnodialog)"):
            # Kodi asks "keep this change?" a moment after the new skin loads; unanswered, it reverts
            xbmc.executebuiltin("SendClick(yesnodialog,11)")
            answered = True
            continue
        if xbmc.getSkinDir() == SKIN and (answered or second >= 20):
            monitor.waitForAbort(2)
            return xbmc.getSkinDir() == SKIN
    return xbmc.getSkinDir() == SKIN


# -- the wizard ----------------------------------------------------------------
class Progress(object):
    def __init__(self, heading):
        self.dialog = xbmcgui.DialogProgress()
        self.dialog.create(heading, "Starting")

    def update(self, percent, message):
        self.dialog.update(int(percent), message)

    def cancelled(self):
        return self.dialog.iscanceled()

    def close(self):
        self.dialog.close()


def _install_step(results):
    kodi_jobs = [(label, lambda a=addon_id: install_from_kodi(a, cancelled=lambda: progress.cancelled())) for addon_id, label in KODI_REPO_ADDONS]
    # Requests goes first: the steps after it download with it
    jobs = kodi_jobs[:1] + [("Chameleon repository", install_chameleon_repo)] + kodi_jobs[1:]
    jobs += [("Fen Light", install_fenlight),
             ("Chameleon skin (large download, this one takes a while)", lambda: install_from_kodi(SKIN, timeout=900, cancelled=lambda: progress.cancelled()))]
    progress = Progress("Chameleon setup: installing")
    try:
        progress.update(0, "Checking for add-on sources")
        xbmc.executebuiltin("UpdateAddonRepos", True)
        xbmc.Monitor().waitForAbort(6)
        for index, (label, job) in enumerate(jobs):
            if progress.cancelled():
                results.append(("Install", False, "cancelled"))
                return False
            progress.update(100.0 * index / len(jobs), "Installing %s[CR](%d of %d)" % (label, index + 1, len(jobs)))
            try:
                ok = bool(job())
                note = "" if ok else "did not install"
            except Exception as exc:  # one failure must not stop the rest
                ok, note = False, str(exc)
                common.log("setup: %s failed: %r" % (label, exc))
            results.append((label.split(" (")[0], ok, note))
    finally:
        progress.close()
    return True


def _config_step(results):
    progress = Progress("Chameleon setup: configuring")
    jobs = [("Fen Light tweaks (sort orders and fixes)", apply_fenlight_tweaks),
            ("Fen Light as the default player", configure_players),
            ("Kodi options", configure_kodi)]
    try:
        for index, (label, job) in enumerate(jobs):
            progress.update(100.0 * index / len(jobs), label)
            try:
                ok = bool(job())
                note = "" if ok else "not applied"
            except Exception as exc:
                ok, note = False, str(exc)
                common.log("setup: %s failed: %r" % (label, exc))
            results.append((label, ok, note))
    finally:
        progress.close()


def _accounts_step(results):
    from . import accounts

    steps = [("trakt", "Trakt", accounts.trakt_sign_in),
             ("pm", "Premiumize", accounts.pm_set_key)]
    for service, label, sign_in in steps:
        if accounts.is_signed_in(service):
            results.append((label + " sign-in", True, "already signed in"))
            continue
        if not common.confirm("Sign in to %s now?[CR][CR]You can skip this and do it later from the Chameleon menu." % label,
                              "Chameleon setup: accounts"):
            results.append((label + " sign-in", False, "skipped"))
            continue
        try:
            sign_in()
        except Exception as exc:
            common.log("setup: %s sign-in failed: %r" % (label, exc))
        results.append((label + " sign-in", accounts.is_signed_in(service),
                        "" if accounts.is_signed_in(service) else "not completed"))
    try:
        accounts.push_all()
    except Exception as exc:
        common.log("setup: account push failed: %r" % exc)


def _look_step(results):
    from . import presets

    ok = switch_skin()
    results.append(("Switch to the Chameleon skin", ok, "" if ok else "skin not active"))
    if not ok:
        return
    xbmc.Monitor().waitForAbort(4)
    chosen = presets.choose()
    results.append(("Choose a look", bool(chosen), "" if chosen else "kept the default look"))


def _summary(results):
    lines = []
    for label, ok, note in results:
        mark = "[COLOR FF4CAF50]Done[/COLOR]" if ok else "[COLOR FFFFB300]Not done[/COLOR]"
        lines.append("%s   %s%s" % (mark, label, (" (%s)" % note) if note else ""))
    xbmcgui.Dialog().textviewer("Chameleon setup: summary", "[CR]".join(lines))


def run(first_run=False):
    intro = ("This installs what Chameleon needs, signs you in to Trakt and Premiumize, sets up playback and "
             "lets you pick a look.[CR][CR]It takes a few minutes and needs internet. Start now?")
    if not common.confirm(intro, "Chameleon setup"):
        if first_run:
            save_state(postponed=int(time.time()))
            common.ok("No problem. You can start it any time from Add-ons, Chameleon Helper, Run setup wizard.")
        return False
    results = []
    if _install_step(results):
        _accounts_step(results)
        _config_step(results)
        _look_step(results)
    save_state(done=True, finished=int(time.time()),
               results=[[label, ok, note] for label, ok, note in results])
    _summary(results)
    return True
