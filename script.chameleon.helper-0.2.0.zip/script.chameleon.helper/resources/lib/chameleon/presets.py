# -*- coding: utf-8 -*-
"""Look and feel presets.

A preset is a JSON file: base colours for the generated theme plus the skin
strings and switches that shape the layout. Built-in presets live in the skin
(special://skin/extras/presets); presets you save live in this add-on's data
folder and can be copied between devices.
"""
import os
import re

import xbmc
import xbmcgui
import xbmcvfs

from . import colors, common

USER_DIR = os.path.join(common.DATA_PATH, "presets")


def skin_dir():
    # the Chameleon skin's own folder, not "the current skin": the setup wizard reads presets before the skin is active
    return xbmcvfs.translatePath("special://home/addons/skin.chameleon/extras/presets/")


def tracked():
    data = common.read_json(os.path.join(skin_dir(), "tracked.json"))
    return list(data.get("strings", [])), list(data.get("bools", []))


def load_all():
    found = []
    for folder, builtin in ((skin_dir(), True), (USER_DIR, False)):
        if not os.path.isdir(folder):
            continue
        for name in sorted(os.listdir(folder)):
            if not name.endswith(".json") or name == "tracked.json":
                continue
            data = common.read_json(os.path.join(folder, name))
            if data.get("name"):
                data["_builtin"] = builtin
                data["_file"] = os.path.join(folder, name)
                found.append(data)
    found.sort(key=lambda p: (not p["_builtin"], p.get("order", 99), p["name"].lower()))
    return found


def find(name):
    wanted = (name or "").strip().lower()
    for preset in load_all():
        if preset["name"].lower() == wanted or os.path.splitext(os.path.basename(preset["_file"]))[0].lower() == wanted:
            return preset
    return None


ROW_GROUPS = ("movies.1", "tvshows.1", "mytrakt.1", "whattowatch.1", "nasmovies.1", "nastv.1")
ROW_BEGIN = "    <!-- CHAMELEON-PRESET-ROWS (written when a preset is applied, do not edit by hand) -->"
ROW_END = "    <!-- /CHAMELEON-PRESET-ROWS -->"


def write_row_styles(rows):
    """Set the row style a preset wants for home rows that have no style of their own.

    The styles go into the skin's shortcuts/overrides.xml as property fallbacks, so a
    style picked for a single row in the menu editor always wins. Returns True when the
    file changed (the home menus are rebuilt on the next visit to the home screen).
    """
    path = xbmcvfs.translatePath("special://skin/shortcuts/overrides.xml")
    try:
        with open(path, "r", encoding="utf-8") as handle:
            text = handle.read()
    except (IOError, OSError) as exc:
        common.log("preset rows: cannot read overrides: %r" % exc)
        return False
    cleaned = re.sub(r"\n?%s.*?%s" % (re.escape(ROW_BEGIN), re.escape(ROW_END)), "", text, flags=re.S)
    lines = []
    rows = rows or {}
    for group in ROW_GROUPS:
        style = rows.get(group, rows.get("default", ""))
        if style and style != "Poster":
            lines.append('    <propertyfallback group="%s" property="widgetAspect">%s</propertyfallback>' % (group, style))
    if lines:
        block = "\n".join([ROW_BEGIN] + lines + [ROW_END])
        cleaned = cleaned.replace("</overrides>", block + "\n</overrides>", 1) if "</overrides>" in cleaned else cleaned
    if cleaned == text:
        return False
    try:
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(cleaned)
    except (IOError, OSError) as exc:
        common.log("preset rows: cannot write overrides: %r" % exc)
        return False
    return True


def apply(name, announce=True):
    preset = name if isinstance(name, dict) else find(name)
    if not preset:
        common.ok("Preset '%s' was not found." % name)
        return False
    strings, bools = tracked()
    want_strings = preset.get("strings", {})
    want_bools = preset.get("bools", {})
    for key in sorted(set(strings) | set(want_strings)):
        value = want_strings.get(key, "")
        if value in ("", None):
            xbmc.executebuiltin("Skin.Reset(%s)" % key, True)
        else:
            xbmc.executebuiltin("Skin.SetString(%s,%s)" % (key, value), True)
    for key in sorted(set(bools) | set(want_bools)):
        if want_bools.get(key):
            xbmc.executebuiltin("Skin.SetBool(%s)" % key, True)
        else:
            xbmc.executebuiltin("Skin.Reset(%s)" % key, True)
    xbmc.executebuiltin("Skin.SetString(Chameleon.Preset,%s)" % preset["name"], True)
    rows_changed = write_row_styles(preset.get("rows"))
    bases = dict(colors.DEFAULTS, **preset.get("colors", {}))
    colors.apply_bases(bases, reload=False)
    colors.activate()  # switches theme or reloads the skin, which also picks up the settings above
    # Row styles and the menu template are baked into the home menus. skinshortcuts compares file hashes itself and
    # only rebuilds (then reloads the skin) when something changed, so asking every time is cheap and keeps the
    # menus in step with skin updates even when Kodi has not been restarted.
    if True:
        xbmc.sleep(1500)
        xbmc.executebuiltin("RunScript(script.skinshortcuts,type=buildxml&mainmenuID=300&levels=5&group=mainmenu|powermenu|searchmenu)")
    if announce:
        common.notify("Preset applied: %s" % preset["name"])
    return True


PREVIEW_DIR = os.path.join(common.DATA_PATH, "previews")


def captured_preview(slug):
    """Newest real screenshot captured on this device for a preset, or ''. File names carry a
    timestamp so Kodi's texture cache never shows an older capture."""
    if not os.path.isdir(PREVIEW_DIR):
        return ""
    names = sorted(n for n in os.listdir(PREVIEW_DIR) if n.startswith(slug + "-") and n.endswith(".png"))
    return os.path.join(PREVIEW_DIR, names[-1]) if names else ""


def _input(action):
    # JSON-RPC input also resets Kodi's idle timer, so the screen dim cannot creep into a capture
    xbmc.executeJSONRPC('{"jsonrpc":"2.0","id":1,"method":"Input.ExecuteAction","params":{"action":"%s"}}' % action)


def capture_previews():
    """Apply every preset in turn, photograph the home screen, then restore the current look."""
    import time

    presets = load_all()
    if not common.confirm("This applies each look in turn and takes a real screenshot of it for the preset chooser. "
                          "It takes about %d minutes. Leave the remote alone until it says it is done. Start now?"
                          % max(1, len(presets))):
        return False
    original = xbmc.getInfoLabel("Skin.String(Chameleon.Preset)")
    monitor = xbmc.Monitor()
    common.ensure_dir(PREVIEW_DIR)
    stamp = int(time.time())
    done = 0
    for preset in presets:
        slug = os.path.splitext(os.path.basename(preset["_file"]))[0]
        apply(preset, announce=False)
        if monitor.waitForAbort(50):
            return False
        _input("noop")
        xbmc.executebuiltin("Dialog.Close(all,true)", True)
        xbmc.executebuiltin("ActivateWindow(Home)", True)
        xbmc.sleep(2500)
        _input("noop")
        xbmc.executebuiltin("SetFocus(300,0,absolute)", True)
        xbmc.sleep(1500)
        side = bool(preset.get("bools", {}).get("Home.VerticalMenu"))
        _input("right" if side else "down")   # menu -> page
        xbmc.sleep(1500)
        _input("down")                        # on to a content row so the focus style shows
        xbmc.sleep(6000)                      # artwork and the info panel settle
        target = os.path.join(PREVIEW_DIR, "%s-%d.png" % (slug, stamp))
        xbmc.executebuiltin("TakeScreenshot(%s,sync)" % target, True)
        xbmc.sleep(1500)
        if os.path.exists(target):
            done += 1
            for name in os.listdir(PREVIEW_DIR):  # drop older captures of this look
                if name.startswith(slug + "-") and name.endswith(".png") and name != os.path.basename(target):
                    try:
                        os.remove(os.path.join(PREVIEW_DIR, name))
                    except OSError:
                        pass
        else:
            common.log("preview capture failed for %s" % slug)
    if original and find(original):
        apply(original, announce=False)
        monitor.waitForAbort(45)
    common.ok("Preview screenshots captured for %d of %d looks." % (done, len(presets)))
    return True


def choose():
    presets = load_all()
    if not presets:
        common.ok("No presets were found in the skin.")
        return False
    current = xbmc.getInfoLabel("Skin.String(Chameleon.Preset)")
    items = []
    for preset in presets:
        label = preset["name"] if preset["_builtin"] else "%s (saved)" % preset["name"]
        if preset["name"] == current:
            label = "%s  (current)" % label
        item = xbmcgui.ListItem(label, preset.get("description", ""))
        slug = os.path.splitext(os.path.basename(preset["_file"]))[0]
        # order: a capture made on this device, the real screenshot shipped with the skin, the older mockup
        preview = captured_preview(slug)
        for shipped in ("special://skin/extras/previews/presets/%s_full.jpg" % slug,
                        "special://skin/extras/previews/presets/%s.jpg" % slug):
            if not preview and preset["_builtin"] and xbmcvfs.exists(shipped):
                preview = shipped
        if preview:
            item.setArt({"icon": preview, "thumb": preview})
        items.append(item)
    preselect = next((i for i, p in enumerate(presets) if p["name"] == current), -1)
    heading = "Choose a preset (current: %s)" % current if current else "Choose a preset (none applied yet)"
    # Large preview layout: the skin's select dialog shows a big image beside the list while this is set.
    xbmc.executebuiltin("SetProperty(SkinViewtypes.DialogIsActive,1,Home)", True)
    try:
        choice = xbmcgui.Dialog().select(heading, items, preselect=preselect, useDetails=True)
    finally:
        xbmc.executebuiltin("ClearProperty(SkinViewtypes.DialogIsActive,Home)", True)
    if choice < 0:
        return False
    return apply(presets[choice])


def capture(name):
    strings, bools = tracked()
    return {
        "name": name,
        "description": "Saved from your settings",
        "colors": colors.load() if colors.is_active() else {},
        "strings": {k: v for k, v in ((k, xbmc.getInfoLabel("Skin.String(%s)" % k)) for k in strings) if v},
        "bools": {k: True for k in bools if xbmc.getCondVisibility("Skin.HasSetting(%s)" % k)},
    }


def save_current():
    name = common.text_input("Name this preset", "My look")
    if not name:
        return False
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "preset"
    path = os.path.join(common.ensure_dir(USER_DIR), "%s.json" % slug)
    if os.path.isfile(path) and not common.confirm("Replace the saved preset '%s'?" % name):
        return False
    common.write_json(path, capture(name))
    xbmc.executebuiltin("Skin.SetString(Chameleon.Preset,%s)" % name)
    common.notify("Preset saved: %s" % name)
    return True
