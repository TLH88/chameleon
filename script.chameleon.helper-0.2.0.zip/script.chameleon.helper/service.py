# -*- coding: utf-8 -*-
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

import xbmc  # noqa: E402

from chameleon import accounts, colors, common  # noqa: E402

SYNC_INTERVAL = 15 * 60


def apply_options():
    """Kodi settings the user asked Chameleon to hold. Edit options.json in the helper's data folder to change them."""
    options = common.read_json(common.data_file("options.json"), {}) or {}
    if options.get("disable_mouse"):
        common.jsonrpc("Settings.SetSettingValue", {"setting": "input.enablemouse", "value": False})


def main():
    monitor = xbmc.Monitor()
    try:
        apply_options()
    except Exception as exc:
        common.log("options failed: %r" % exc)
    if monitor.waitForAbort(12):
        return
    try:  # a fresh box: offer the setup wizard once Kodi has settled
        from chameleon import setup

        if setup.needs_first_run():
            xbmc.executebuiltin("RunScript(script.chameleon.helper,mode=setup&first=1)")
    except Exception as exc:
        common.log("first-run check failed: %r" % exc)
    if monitor.waitForAbort(8):
        return
    try:
        colors.restore_theme_file()
    except Exception as exc:  # the service must never take Kodi down with it
        common.log("theme restore failed: %r" % exc)
    try:
        accounts.push_all()  # covers add-ons installed since the last run
    except Exception as exc:
        common.log("startup push failed: %r" % exc)
    while not monitor.abortRequested():
        try:
            accounts.background_sync()
        except Exception as exc:
            common.log("account sync failed: %r" % exc)
        if monitor.waitForAbort(SYNC_INTERVAL):
            break


if __name__ == "__main__":
    main()
